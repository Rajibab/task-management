import React, { useState, useEffect } from 'react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, LineChart, Line 
} from 'recharts';
import { 
  Search, BarChart3, ShieldAlert, Sparkles, Printer, 
  ArrowUpRight, ArrowDownRight, RefreshCcw, Landmark, Sliders 
} from 'lucide-react';

export default function SEOReports({ 
  seoReport, 
  setSeoReport, 
  currentRole, 
  logActivity,
  brandColor = 'indigo'
}) {
  
  // Date comparison state
  const [comparisonDate, setComparisonDate] = useState('q1-vs-q2'); // q1-vs-q2 or dec-vs-may
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  // Deep interactive state mirroring the report data to allow instantaneous edits
  const [da, setDa] = useState(seoReport.da);
  const [pa, setPa] = useState(seoReport.pa);
  const [techScore, setTechScore] = useState(seoReport.technicalScore);
  const [trafficVal, setTrafficVal] = useState(34500); // represents current month's traffic
  
  // Dynamic Recharts data state
  const [trafficData, setTrafficData] = useState([...seoReport.trafficHistory]);

  // Synchronize dynamic updates back to general database state
  useEffect(() => {
    const updatedData = trafficData.map((item, idx) => {
      if (idx === trafficData.length - 1) {
        return { 
          ...item, 
          traffic: trafficVal, 
          backlinks: Math.round(trafficVal * 0.082) // scale backlinks mathematically 
        };
      }
      return item;
    });

    setTrafficData(updatedData);
    setSeoReport(prev => ({
      ...prev,
      da: parseInt(da) || 30,
      pa: parseInt(pa) || 30,
      technicalScore: parseInt(techScore) || 70,
      trafficHistory: updatedData
    }));
  }, [da, pa, techScore, trafficVal]);

  // Action: Reset standard report numbers
  const handleResetMetrics = () => {
    setDa(42);
    setPa(38);
    setTechScore(84);
    setTrafficVal(34500);
    setTrafficData([...seoReport.trafficHistory]);
    logActivity('SEO Metrics Reset', 'Reverted database SEO performance variables to baseline.');
  };

  // Action: Launch browser print
  const handlePrintPDF = () => {
    setIsGeneratingPdf(true);
    setTimeout(() => {
      window.print();
      setIsGeneratingPdf(false);
      logActivity('SEO PDF Generated', 'Exported AeroMedia Group SEO report as high-resolution PDF brief.');
    }, 500);
  };

  // Real-time AI Summary generator
  const getAiSummary = () => {
    if (techScore < 75) {
      return `⚠️ DANGER SCORE: Your technical SEO score has dropped to ${techScore}%. Our scanners detected urgent crawl issues. Critical broken redirect patterns are blocking key directory indexations. We highly suggest resolving these backend errors immediately. Target backlinks acquisition to boost your DA/PA (currently ${da}/${pa}) which are trailing industry averages.`;
    }
    if (techScore >= 75 && techScore < 90) {
      return `⚡ PROGRESS REPORT: AeroMedia.com is displaying solid progress with a Technical Score of ${techScore}%. Organic keyword acquisitions grew by 18% month-over-month. To break past the Domain Authority threshold of ${da}, we suggest auditing all heavy media assets (currently 14 uncompressed PNG files are slowing load times) and drafting customized long-tail content targeting 'charter flight tracking' directories.`;
    }
    return `🏆 ELITE SCORE: Your website health is optimal at ${techScore}%. Domain and Page authorities (${da}/${pa}) are outperforming 85% of standard tech companies. Search visibility is high, supported by Rank #1 positioning for 'aerospace cloud digital marketing'. Continue building high-quality institutional backlinks to maintain this organic compounding curve.`;
  };

  // Color mapping
  const getBrandTextColor = () => {
    switch (brandColor) {
      case 'emerald': return 'text-emerald-400';
      case 'violet': return 'text-violet-400';
      case 'amber': return 'text-amber-400';
      default: return 'text-indigo-400';
    }
  };

  const getBrandBg = () => {
    switch (brandColor) {
      case 'emerald': return 'bg-emerald-500';
      case 'violet': return 'bg-violet-500';
      case 'amber': return 'bg-amber-500';
      default: return 'bg-indigo-500';
    }
  };

  const getBrandBorderColor = () => {
    switch (brandColor) {
      case 'emerald': return 'border-emerald-500/25';
      case 'violet': return 'border-violet-500/25';
      case 'amber': return 'border-amber-500/25';
      default: return 'border-indigo-500/25';
    }
  };

  return (
    <div className="space-y-6 printable-section">
      
      {/* Top action row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 no-print">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-100">SEO Analyzer & Report Generator</h2>
          <p className="text-xs text-slate-400 mt-1">Audit active keyword positions, organic traffic trajectories, and indexation records.</p>
        </div>
        
        <div className="flex gap-2">
          {currentRole !== 'client' && (
            <button 
              onClick={handleResetMetrics}
              className="flex items-center gap-1 px-3 py-2 bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200 text-xs font-bold rounded-xl cursor-pointer transition-all"
            >
              <RefreshCcw className="w-3.5 h-3.5" /> Reset baseline
            </button>
          )}
          <button 
            onClick={handlePrintPDF}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white rounded-xl shadow-md cursor-pointer transition-all hover:scale-105 active:scale-95 ${getBrandBg()}`}
          >
            <Printer className="w-4 h-4" /> {isGeneratingPdf ? 'Compiling PDF...' : 'Print Report PDF'}
          </button>
        </div>
      </div>

      {/* Printable Corporate Header */}
      <div className="hidden print:flex justify-between items-center border-b border-slate-300 pb-5 mb-5 text-black">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Search Engine Optimization Report Brief</h1>
          <p className="text-[10px] text-slate-600 mt-0.5">Account Target: <strong>{seoReport.clientName} ({seoReport.website})</strong></p>
        </div>
        <div className="text-right">
          <div className="text-sm font-bold text-indigo-600">OmniMark OS Analytics</div>
          <div className="text-[9px] text-slate-500">Report Compiled: {new Date().toLocaleDateString()}</div>
        </div>
      </div>

      {/* Interactive Parameters Adjuster Panel (Visible to Admin/Team) */}
      {currentRole !== 'client' && (
        <div className="p-5 bg-slate-900 border border-slate-800/80 rounded-2xl space-y-4 no-print">
          <div className="flex items-center gap-2 mb-2">
            <Sliders className={`w-4.5 h-4.5 ${getBrandTextColor()}`} />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">Interactive SEO Metrics Controller</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            
            {/* Input 1 */}
            <div>
              <div className="flex justify-between text-[10px] font-bold text-slate-400 mb-1.5">
                <span>Domain Authority (DA)</span>
                <span className="text-indigo-400">{da}</span>
              </div>
              <input 
                type="range" min="10" max="99" value={da} 
                onChange={(e) => setDa(e.target.value)}
                className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-indigo-500 focus:outline-none"
              />
            </div>

            {/* Input 2 */}
            <div>
              <div className="flex justify-between text-[10px] font-bold text-slate-400 mb-1.5">
                <span>Page Authority (PA)</span>
                <span className="text-indigo-400">{pa}</span>
              </div>
              <input 
                type="range" min="10" max="99" value={pa} 
                onChange={(e) => setPa(e.target.value)}
                className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-indigo-500 focus:outline-none"
              />
            </div>

            {/* Input 3 */}
            <div>
              <div className="flex justify-between text-[10px] font-bold text-slate-400 mb-1.5">
                <span>Technical SEO Health Score</span>
                <span className="text-emerald-400">{techScore}%</span>
              </div>
              <input 
                type="range" min="30" max="99" value={techScore} 
                onChange={(e) => setTechScore(e.target.value)}
                className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-emerald-500 focus:outline-none"
              />
            </div>

            {/* Input 4 */}
            <div>
              <div className="flex justify-between text-[10px] font-bold text-slate-400 mb-1.5">
                <span>Monthly Organic Traffic</span>
                <span className="text-indigo-400">{parseInt(trafficVal).toLocaleString()}</span>
              </div>
              <input 
                type="range" min="10000" max="60000" value={trafficVal} 
                onChange={(e) => setTrafficVal(e.target.value)}
                className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-indigo-500 focus:outline-none"
              />
            </div>

          </div>
        </div>
      )}

      {/* Main Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
        
        {/* Stat 1 */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl text-center shadow-inner flex flex-col justify-center">
          <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-500">Domain Authority</span>
          <div className={`text-3xl font-extrabold mt-1.5 ${getBrandTextColor()}`}>{da}<span className="text-xs text-slate-600 font-medium">/100</span></div>
          <p className="text-[8px] text-slate-500 mt-1 uppercase font-bold tracking-widest">Moz metrics engine</p>
        </div>

        {/* Stat 2 */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl text-center shadow-inner flex flex-col justify-center">
          <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-500">Page Authority</span>
          <div className="text-3xl font-extrabold mt-1.5 text-slate-200">{pa}<span className="text-xs text-slate-600 font-medium">/100</span></div>
          <p className="text-[8px] text-slate-500 mt-1 uppercase font-bold tracking-widest">Moz metrics engine</p>
        </div>

        {/* Stat 3 */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl text-center shadow-inner flex flex-col justify-center">
          <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-500">Technical SEO Score</span>
          <div className={`text-3xl font-extrabold mt-1.5 ${techScore >= 80 ? 'text-emerald-400' : 'text-amber-400'}`}>{techScore}%</div>
          <p className="text-[8px] text-slate-500 mt-1 uppercase font-bold tracking-widest">Indexation & Crawl Health</p>
        </div>

        {/* Stat 4 */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl text-center shadow-inner flex flex-col justify-center">
          <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-500">Organic Keywords</span>
          <div className="text-3xl font-extrabold mt-1.5 text-slate-200">2,140</div>
          <p className="text-[8px] text-slate-500 mt-1 uppercase font-bold tracking-widest">Google Index Rankings</p>
        </div>

      </div>

      {/* AI Suggestions and Traffic Graph Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Area Graph */}
        <div className="lg:col-span-8 p-5 bg-slate-900 border border-slate-800 rounded-2xl">
          <div className="flex justify-between items-center mb-4.5">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Organic Traffic Growth Profile</h3>
              <p className="text-[10px] text-slate-500 mt-0.5">Real-time compilation of search conversions</p>
            </div>
            <span className="text-[9px] uppercase tracking-wider font-bold text-slate-500 bg-slate-950 px-2 py-1 rounded">Live Rendered</span>
          </div>

          <div className="h-64 mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trafficData}>
                <defs>
                  <linearGradient id="seoTrafficGlow" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.25}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.03)" />
                <XAxis dataKey="name" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                <Tooltip 
                  contentStyle={{ background: '#090d16', borderColor: '#1e293b', borderRadius: '12px', fontSize: '11px', color: '#fff' }}
                />
                <Area type="monotone" dataKey="traffic" name="Visits" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#seoTrafficGlow)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* AI Recommendations Panel */}
        <div className="lg:col-span-4 p-5 bg-slate-900 border border-slate-800 rounded-2xl flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 p-1 px-2.5 bg-slate-950 border border-slate-800 rounded-full w-max mb-3.5">
              <Sparkles className={`w-3.5 h-3.5 text-indigo-400 animate-pulse`} />
              <span className="text-[9px] uppercase tracking-wider font-bold text-slate-300">AI Report Summarizer</span>
            </div>

            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">Diagnostic Summary</h3>
            <p className="text-[11px] text-slate-400 mt-2.5 leading-relaxed whitespace-pre-line">
              {getAiSummary()}
            </p>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-800/80 text-[10px] text-slate-500">
            <span className="font-semibold text-slate-400 uppercase tracking-widest text-[8px] block mb-1">Crawl Details</span>
            <div>Target Domain: <span className="font-bold text-indigo-300">aeromedia.com</span></div>
            <div>Core Region: <span className="font-bold text-slate-300">Global (US/UK/EU)</span></div>
          </div>
        </div>

      </div>

      {/* Before vs After and Keyword Rankings */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Date / Before vs After Comparison */}
        <div className="p-5 bg-slate-900 border border-slate-800/80 rounded-2xl">
          <div className="flex justify-between items-center mb-4 border-b border-slate-800 pb-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Chronological Comparison</h3>
            <div className="flex gap-1 bg-slate-950 p-1 border border-slate-800 rounded-lg no-print">
              <button
                onClick={() => setComparisonDate('q1-vs-q2')}
                className={`px-2 py-1 rounded text-[9px] font-extrabold cursor-pointer transition-all ${
                  comparisonDate === 'q1-vs-q2' ? 'bg-indigo-500 text-white' : 'text-slate-400'
                }`}
              >
                Q1 vs Q2 Delta
              </button>
              <button
                onClick={() => setComparisonDate('dec-vs-may')}
                className={`px-2 py-1 rounded text-[9px] font-extrabold cursor-pointer transition-all ${
                  comparisonDate === 'dec-vs-may' ? 'bg-indigo-500 text-white' : 'text-slate-400'
                }`}
              >
                Dec vs May Delta
              </button>
            </div>
          </div>

          <div className="space-y-4 text-xs">
            {comparisonDate === 'q1-vs-q2' ? (
              <>
                <div className="p-3 bg-slate-950/40 border border-slate-900 rounded-xl flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-300">Organic Visits</div>
                    <span className="text-[10px] text-slate-500">Q1: 18,200 vs Q2 Forecast: 34,500</span>
                  </div>
                  <span className="bg-emerald-500/10 border border-emerald-500/35 text-emerald-400 px-2 py-1 rounded-full font-bold flex items-center gap-0.5 text-[10px]">
                    <ArrowUpRight className="w-3.5 h-3.5" /> +89.5%
                  </span>
                </div>

                <div className="p-3 bg-slate-950/40 border border-slate-900 rounded-xl flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-300">Domain Backlinks</div>
                    <span className="text-[10px] text-slate-500">Q1: 1,510 vs Q2 Forecast: 2,840</span>
                  </div>
                  <span className="bg-emerald-500/10 border border-emerald-500/35 text-emerald-400 px-2 py-1 rounded-full font-bold flex items-center gap-0.5 text-[10px]">
                    <ArrowUpRight className="w-3.5 h-3.5" /> +88.0%
                  </span>
                </div>

                <div className="p-3 bg-slate-950/40 border border-slate-900 rounded-xl flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-300">Technical Health Audit</div>
                    <span className="text-[10px] text-slate-500">Q1 Crawl: 76% vs Q2 Optimize: {techScore}%</span>
                  </div>
                  <span className={`px-2 py-1 rounded-full font-bold flex items-center gap-0.5 text-[10px] ${
                    techScore - 76 >= 0 
                      ? 'bg-emerald-500/10 border-emerald-500/35 text-emerald-400' 
                      : 'bg-red-500/10 border-red-500/35 text-red-400'
                  }`}>
                    {techScore - 76 >= 0 ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />} 
                    {techScore - 76}%
                  </span>
                </div>
              </>
            ) : (
              <>
                <div className="p-3 bg-slate-950/40 border border-slate-900 rounded-xl flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-300">Organic Visits</div>
                    <span className="text-[10px] text-slate-500">Dec: 14,200 vs May: {trafficVal.toLocaleString()}</span>
                  </div>
                  <span className="bg-emerald-500/10 border border-emerald-500/35 text-emerald-400 px-2 py-1 rounded-full font-bold flex items-center gap-0.5 text-[10px]">
                    <ArrowUpRight className="w-3.5 h-3.5" /> +{Math.round(((trafficVal - 14200) / 14200) * 100)}%
                  </span>
                </div>

                <div className="p-3 bg-slate-950/40 border border-slate-900 rounded-xl flex items-center justify-between">
                  <div>
                    <div className="font-bold text-slate-300">Index Keywords</div>
                    <span className="text-[10px] text-slate-500">Dec: 840 vs May: 2,140</span>
                  </div>
                  <span className="bg-emerald-500/10 border border-emerald-500/35 text-emerald-400 px-2 py-1 rounded-full font-bold flex items-center gap-0.5 text-[10px]">
                    <ArrowUpRight className="w-3.5 h-3.5" /> +154.7%
                  </span>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Keywords rankings tracker */}
        <div className="p-5 bg-slate-900 border border-slate-800/80 rounded-2xl">
          <div className="flex justify-between items-center mb-4 border-b border-slate-800 pb-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Search Keywords Core Index</h3>
            <span className="text-[9px] uppercase tracking-wider font-bold text-slate-500">Top 5 keywords</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left text-slate-300">
              <thead className="text-[9px] uppercase font-bold text-slate-500 border-b border-slate-800 bg-slate-950/20">
                <tr>
                  <th className="py-2.5 px-3">Keyword Query</th>
                  <th className="py-2.5 px-3 text-center">Rank</th>
                  <th className="py-2.5 px-3 text-center">Vol</th>
                  <th className="py-2.5 px-3 text-right">Traffic Share</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/40">
                {seoReport.organicKeywords.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-950/20 transition-all select-none">
                    <td className="py-2.5 px-3 font-semibold text-slate-200">{item.keyword}</td>
                    <td className="py-2.5 px-3 text-center font-extrabold text-indigo-300">#{item.rank}</td>
                    <td className="py-2.5 px-3 text-center text-slate-400 tabular-nums">{item.volume}</td>
                    <td className="py-2.5 px-3 text-right font-extrabold text-emerald-400">+{item.traffic}/mo</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>

    </div>
  );
}
