import React, { useState } from 'react';
import { 
  CreditCard, DollarSign, Printer, Download, Clock, 
  HelpCircle, Sparkles, X, ChevronRight, History, Settings, Lock, Plus 
} from 'lucide-react';

export default function Billing({ 
  invoices, 
  setInvoices, 
  renegotiationLogs, 
  setRenegotiationLogs, 
  clients, 
  setClients, 
  currentRole, 
  logActivity,
  brandColor = 'indigo',
  currentUser = null,
  onOpenAuth = () => {}
}) {
  
  // Modal toggles
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [isRenegotiateOpen, setIsRenegotiateOpen] = useState(false);
  const [isCreateInvoiceOpen, setIsCreateInvoiceOpen] = useState(false);

  // Renegotiation Form State
  const [renegotiateForm, setRenegotiateForm] = useState({
    invoiceId: '',
    clientName: '',
    oldPrice: 0,
    newPrice: '',
    note: ''
  });

  // New Invoice Form State
  const [createInvoiceForm, setCreateInvoiceForm] = useState({
    clientId: 'cli-1',
    amount: '',
    deliverables: '',
    dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    recurring: false
  });

  // Billing Stats calculations
  const totalInvoiced = invoices.reduce((sum, inv) => sum + inv.total, 0);
  const totalPaid = invoices.filter(i => i.status === 'Paid').reduce((sum, inv) => sum + inv.total, 0);
  const totalOutstanding = invoices.filter(i => i.status === 'Due' || i.status === 'Overdue').reduce((sum, inv) => sum + inv.total, 0);
  const totalOverdue = invoices.filter(i => i.status === 'Overdue').reduce((sum, inv) => sum + inv.total, 0);

  // Action: Trigger recurring invoice billing switch
  const handleToggleRecurring = (id, clientName, currentState) => {
    setInvoices(prev => prev.map(inv => inv.id === id ? { ...inv, recurring: !currentState } : inv));
    logActivity('Invoice Retainer Toggled', `Flipped recurring billing for invoice ${id} (${clientName}) to ${!currentState ? 'ENABLED' : 'DISABLED'}.`);
  };

  // Action: Load invoice into renegotiate form
  const handleOpenRenegotiate = (invoice) => {
    setRenegotiateForm({
      invoiceId: invoice.id,
      clientName: invoice.clientName,
      oldPrice: invoice.amount,
      newPrice: '',
      note: ''
    });
    setIsRenegotiateOpen(true);
  };

  // Action: Save Price Renegotiation
  const handleSaveRenegotiation = (e) => {
    e.preventDefault();
    const newPriceVal = parseFloat(renegotiateForm.newPrice);
    if (!newPriceVal || isNaN(newPriceVal)) {
      alert('Please enter a valid price amount');
      return;
    }

    // 1. Calculate new GST and Total
    const newGst = Math.round(newPriceVal * 0.18);
    const newTotal = newPriceVal + newGst;

    // 2. Update Invoice records
    setInvoices(prev => prev.map(inv => {
      if (inv.id === renegotiateForm.invoiceId) {
        return {
          ...inv,
          amount: newPriceVal,
          taxGst: newGst,
          total: newTotal
        };
      }
      return inv;
    }));

    // 3. Update Client profile active monthly recurring billing contract
    setClients(prev => prev.map(cli => {
      if (cli.companyName === renegotiateForm.clientName) {
        return {
          ...cli,
          monthlyBilling: newPriceVal
        };
      }
      return cli;
    }));

    // 4. Log negotiation ledger
    const logEntry = {
      id: `rn-${Date.now()}`,
      clientName: renegotiateForm.clientName,
      oldPrice: renegotiateForm.oldPrice,
      newPrice: newPriceVal,
      date: new Date().toISOString().split('T')[0],
      approvedBy: currentRole === 'admin' ? 'Admin (RAJIB)' : 'Manager (Chloe)',
      note: renegotiateForm.note || 'Contract price renegotiated'
    };

    setRenegotiationLogs(prev => [logEntry, ...prev]);
    logActivity('Contract Renegotiated', `Adjusted pricing for ${renegotiateForm.clientName} invoice #${renegotiateForm.invoiceId} to $${newPriceVal.toLocaleString()} monthly.`);
    setIsRenegotiateOpen(false);
  };

  // Action: Create Custom Invoice
  const handleCreateInvoice = (e) => {
    e.preventDefault();
    const baseAmt = parseFloat(createInvoiceForm.amount);
    if (!baseAmt || isNaN(baseAmt)) {
      alert('Please enter a valid base amount.');
      return;
    }

    const selectedClient = clients.find(c => c.id === createInvoiceForm.clientId) || clients[0];
    const newInvoiceId = `INV-${Date.now().toString().slice(-4)}`;
    const taxGst = Math.round(baseAmt * 0.18);
    const total = baseAmt + taxGst;

    const newInvoice = {
      id: newInvoiceId,
      clientName: selectedClient.companyName,
      clientEmail: selectedClient.email,
      amount: baseAmt,
      taxGst: taxGst,
      total: total,
      issueDate: new Date().toISOString().split('T')[0],
      dueDate: createInvoiceForm.dueDate,
      recurring: createInvoiceForm.recurring,
      status: 'Due',
      serviceList: createInvoiceForm.deliverables.split(',').map(s => s.trim()).filter(Boolean)
    };

    setInvoices(prev => [newInvoice, ...prev]);
    logActivity('Invoice Created', `Generated custom invoice #${newInvoiceId} for ${selectedClient.companyName} totaling $${total.toLocaleString()}.`);
    setIsCreateInvoiceOpen(false);
    
    // Reset Form
    setCreateInvoiceForm({
      clientId: 'cli-1',
      amount: '',
      deliverables: '',
      dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      recurring: false
    });
  };

  // Color matching utilities
  const getBrandTextColor = () => {
    switch (brandColor) {
      case 'emerald': return 'text-emerald-400';
      case 'violet': return 'text-violet-400';
      case 'amber': return 'text-amber-400';
      default: return 'text-indigo-400';
    }
  };

  const getBrandBg = () => {
    switch (brandColor) {
      case 'emerald': return 'bg-emerald-500';
      case 'violet': return 'bg-violet-500';
      case 'amber': return 'bg-amber-500';
      default: return 'bg-indigo-500';
    }
  };

  const getBrandBorderColor = () => {
    switch (brandColor) {
      case 'emerald': return 'border-emerald-500/20';
      case 'violet': return 'border-violet-500/20';
      case 'amber': return 'border-amber-500/20';
      default: return 'border-indigo-500/20';
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Paid': return 'bg-emerald-500/10 border-emerald-500/35 text-emerald-400';
      case 'Due': return 'bg-amber-500/10 border-amber-500/35 text-amber-400';
      default: return 'bg-red-500/10 border-red-500/35 text-red-400';
    }
  };

  if (!currentUser) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-6 text-center max-w-xl mx-auto space-y-6 select-none animate-in fade-in duration-300">
        <div className="p-6 bg-slate-900 border border-slate-800 rounded-3xl relative shadow-[0_0_50px_-12px_rgba(99,102,241,0.15)] w-full">
          <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500/10 to-violet-500/10 rounded-3xl opacity-50 blur-[2px]" />
          <div className="relative p-4 bg-slate-950 rounded-2xl border border-slate-850 text-indigo-400 w-14 h-14 flex items-center justify-center mx-auto mb-3 shadow-inner">
            <CreditCard className="w-6 h-6 animate-pulse" />
          </div>
          <h3 className="text-base font-bold text-slate-200 relative">Financial Database Lock</h3>
          <p className="text-xs text-slate-500 leading-relaxed mt-2.5 relative">
            Security Clearance Required. Access to real-time billing ledgers, auto-recurring retainer details, pricing renegotiation schedules, and invoice downloads is restricted.
          </p>
        </div>
        
        <button
          type="button"
          onClick={onOpenAuth}
          className="px-6 py-3 bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700 text-white rounded-xl font-bold text-xs cursor-pointer hover:scale-105 active:scale-95 transition-all shadow-[0_0_20px_-3px_rgba(99,102,241,0.4)] flex items-center gap-2"
        >
          <Lock className="w-3.5 h-3.5" /> Authenticate Session to Unlock
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-100">Financial Ledger & Invoices</h2>
          <p className="text-xs text-slate-400 mt-1">Audit active billing cycles, download corporate receipts, and manage discount adjustments.</p>
        </div>
        
        {currentUser && currentUser.role === 'admin' && (
          <button 
            type="button"
            onClick={() => setIsCreateInvoiceOpen(true)}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white rounded-xl shadow-md cursor-pointer transition-all hover:scale-105 active:scale-[0.95] ${getBrandBg()}`}
          >
            <Plus className="w-4 h-4" /> Generate Custom Invoice
          </button>
        )}
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        
        {/* Metric 1 */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-500">Gross Billing</span>
            <div className="text-xl font-bold text-slate-200 mt-1">${totalInvoiced.toLocaleString()}</div>
          </div>
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-indigo-400">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 2 */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-500">Revenue Collected</span>
            <div className="text-xl font-bold text-emerald-400 mt-1">${totalPaid.toLocaleString()}</div>
          </div>
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-emerald-400">
            <CreditCard className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 3 */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-500">Outstanding (Due)</span>
            <div className="text-xl font-bold text-amber-400 mt-1">${totalOutstanding.toLocaleString()}</div>
          </div>
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-amber-400">
            <Clock className="w-5 h-5 animate-pulse" />
          </div>
        </div>

        {/* Metric 4 */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-500">Contract Overdue</span>
            <div className="text-xl font-bold text-red-400 mt-1">${totalOverdue.toLocaleString()}</div>
          </div>
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-red-400">
            <Clock className="w-5 h-5" />
          </div>
        </div>

      </div>

      {/* Main invoices grid table */}
      <div className="p-5 bg-slate-900 border border-slate-800/80 rounded-2xl">
        <div className="flex justify-between items-center mb-4.5">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Invoices Register</h3>
          <span className="text-[10px] text-slate-500 font-semibold">18% GST applied mathematically</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left text-slate-300">
            <thead className="text-[9px] uppercase font-bold text-slate-500 border-b border-slate-800 bg-slate-950/20">
              <tr>
                <th className="py-3 px-4">Invoice ID</th>
                <th className="py-3 px-4">Partner Client</th>
                <th className="py-3 px-4 text-center">Base Retainer</th>
                <th className="py-3 px-4 text-center">GST Tax (18%)</th>
                <th className="py-3 px-4 text-center">Total Price</th>
                <th className="py-3 px-4">Invoice Date</th>
                <th className="py-3 px-4 text-center">Auto-Recurring</th>
                <th className="py-3 px-4 text-center">Billing State</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {invoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-950/20 transition-all select-none">
                  <td className="py-3.5 px-4 font-bold text-slate-300">#{inv.id}</td>
                  <td className="py-3.5 px-4 font-bold text-slate-200">{inv.clientName}</td>
                  <td className="py-3.5 px-4 text-center font-bold text-slate-300">${inv.amount.toLocaleString()}</td>
                  <td className="py-3.5 px-4 text-center text-slate-400">${inv.taxGst.toLocaleString()}</td>
                  <td className="py-3.5 px-4 text-center font-extrabold text-slate-100">${inv.total.toLocaleString()}</td>
                  <td className="py-3.5 px-4 text-slate-500 font-semibold">{inv.issueDate}</td>
                  <td className="py-3.5 px-4 text-center">
                    <button
                      onClick={() => handleToggleRecurring(inv.id, inv.clientName, inv.recurring)}
                      className={`text-[9px] font-bold px-2 py-0.5 rounded cursor-pointer border ${
                        inv.recurring 
                          ? 'bg-indigo-500/10 border-indigo-500/35 text-indigo-400' 
                          : 'bg-slate-950 border-slate-800 text-slate-600'
                      }`}
                    >
                      {inv.recurring ? 'Active (Monthly)' : 'Disabled'}
                    </button>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <span className={`text-[8px] font-extrabold uppercase border px-2 py-0.5 rounded-full shadow-inner ${getStatusBadge(inv.status)}`}>
                      {inv.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex justify-end gap-2">
                      {currentRole === 'admin' && (
                        <button
                          onClick={() => handleOpenRenegotiate(inv)}
                          className="px-2 py-1.5 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200 rounded-lg cursor-pointer font-bold text-[10px] transition-all bg-slate-950"
                        >
                          Renegotiate
                        </button>
                      )}
                      <button
                        onClick={() => setSelectedInvoice(inv)}
                        className={`px-2.5 py-1.5 rounded-lg text-white font-bold text-[10px] cursor-pointer hover:scale-105 active:scale-95 transition-all shadow ${getBrandBg()}`}
                      >
                        Inspect Invoice
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pricing Renegotiation Timeline and logs */}
      <div className="p-5 bg-slate-900 border border-slate-800/80 rounded-2xl">
        <h3 className="text-sm font-bold text-slate-200 mb-4 flex items-center gap-2">
          <History className={`w-4.5 h-4.5 ${getBrandTextColor()}`} />
          Pricing Adjustment Timeline Audit
        </h3>

        <div className="space-y-4">
          {renegotiationLogs.map((log) => (
            <div 
              key={log.id} 
              className="p-3.5 bg-slate-950/40 border border-slate-900 hover:border-slate-800/60 rounded-xl transition-all flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs leading-relaxed"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-200">{log.clientName}</span>
                  <span className="text-[9px] bg-indigo-500/10 text-indigo-400 border border-indigo-500/35 px-1.5 py-0.5 rounded font-extrabold uppercase">Revised</span>
                </div>
                <p className="text-[10px] text-slate-500 mt-1 font-medium">Auditor Remarks: <span className="text-slate-400 italic">"{log.note}"</span></p>
              </div>

              <div className="flex items-center gap-4 text-right">
                <div>
                  <span className="text-[9px] uppercase tracking-wider font-extrabold text-slate-500 block mb-0.5">Price Shift</span>
                  <span className="text-slate-400 line-through">${log.oldPrice.toLocaleString()}</span>{' '}
                  <span className="font-extrabold text-emerald-400">${log.newPrice.toLocaleString()}</span>
                </div>
                <div className="text-[10px] text-slate-500 font-semibold border-l border-slate-800 pl-4">
                  <div>Approved By: {log.approvedBy}</div>
                  <div>Logged: {log.date}</div>
                </div>
              </div>
            </div>
          ))}

          {renegotiationLogs.length === 0 && (
            <p className="text-slate-500 text-center italic py-4">No price revisions logged in local timeline databases.</p>
          )}
        </div>
      </div>

      {/* MODAL 1: CORPORATE INVOICE VIEWER */}
      {selectedInvoice && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200 text-slate-800">
            
            {/* Header / Actions bar */}
            <div className="p-4 bg-slate-900 border-b border-slate-800 flex justify-between items-center text-white no-print">
              <span className="text-xs font-bold flex items-center gap-1.5">
                <Printer className="w-4 h-4 text-indigo-400" /> Digital Invoicing Audit
              </span>
              <div className="flex gap-2">
                <button 
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 rounded-lg text-xs font-bold text-white cursor-pointer transition-all flex items-center gap-1 shadow"
                >
                  <Download className="w-3.5 h-3.5" /> Print Invoice Receipt
                </button>
                <button onClick={() => setSelectedInvoice(null)} className="p-1 text-slate-400 hover:text-white rounded-lg cursor-pointer">
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Corporate Invoice Document Sheet (Light Theme optimized) */}
            <div className="flex-1 p-8 overflow-y-auto space-y-6 bg-white print:p-0">
              
              {/* Document Header */}
              <div className="flex justify-between items-start border-b border-slate-100 pb-5">
                <div>
                  <h1 className="text-2xl font-black text-indigo-600 tracking-wide">OMNIMARK AGENCY</h1>
                  <p className="text-[10px] text-slate-500 mt-1 leading-normal max-w-xs">
                    78 Enterprise Way, Suite 400A<br />
                    San Francisco, CA 94107<br />
                    Tax Registry: GSTIN-9824XJ821
                  </p>
                </div>
                
                <div className="text-right">
                  <h2 className="text-lg font-bold text-slate-900">INVOICE RECEIPT</h2>
                  <div className="text-xs text-slate-500 mt-1">Invoice Reference: <strong className="text-slate-800">#INV-{selectedInvoice.id}</strong></div>
                  <div className="text-[10px] text-slate-400 mt-0.5">Issued: {selectedInvoice.issueDate} | Due: {selectedInvoice.dueDate}</div>
                </div>
              </div>

              {/* Bill To */}
              <div className="grid grid-cols-2 gap-6 text-xs border-b border-slate-100 pb-5">
                <div>
                  <span className="text-[8px] uppercase tracking-wider font-extrabold text-slate-400 block mb-1">CLIENT BILL TO</span>
                  <div className="font-bold text-slate-800">{selectedInvoice.clientName}</div>
                  <p className="text-[10px] text-slate-500 mt-0.5 leading-relaxed">
                    Corporate Partner Account<br />
                    Contact: {selectedInvoice.clientEmail}
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-[8px] uppercase tracking-wider font-extrabold text-slate-400 block mb-1">PAYMENT STATUS</span>
                  <span className={`text-[9px] font-extrabold uppercase border px-3 py-1 rounded-full shadow-inner ${
                    selectedInvoice.status === 'Paid' 
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-600' 
                      : 'bg-red-50 border-red-200 text-red-600'
                  }`}>
                    {selectedInvoice.status}
                  </span>
                </div>
              </div>

              {/* Items Table */}
              <div>
                <table className="w-full text-xs text-left text-slate-700">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-[9px] uppercase tracking-wider font-bold text-slate-500">
                      <th className="py-2.5 px-3">Subscribed Campaign Service</th>
                      <th className="py-2.5 px-3 text-center">Frequency</th>
                      <th className="py-2.5 px-3 text-right">Base Cost</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {selectedInvoice.serviceList?.map((srv, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/50">
                        <td className="py-3 px-3 font-semibold text-slate-800">{srv}</td>
                        <td className="py-3 px-3 text-center text-slate-500">{selectedInvoice.recurring ? 'Monthly' : 'One-Time'}</td>
                        <td className="py-3 px-3 text-right font-semibold text-slate-800">${(selectedInvoice.amount / (selectedInvoice.serviceList.length || 1)).toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Totals Breakdown */}
              <div className="flex justify-end pt-4 border-t border-slate-100 text-xs">
                <div className="w-64 space-y-1.5 text-slate-500 font-medium">
                  <div className="flex justify-between">
                    <span>Campaign Subtotal</span>
                    <span className="text-slate-800">${selectedInvoice.amount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>GST Additions (18% Sales Tax)</span>
                    <span className="text-slate-800">+${selectedInvoice.taxGst.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-slate-100 text-sm font-bold text-indigo-600">
                    <span>Compounded Grand Total</span>
                    <span>${selectedInvoice.total.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Terms */}
              <div className="pt-6 border-t border-slate-100 text-[9px] text-slate-400 leading-relaxed">
                <h4 className="font-bold text-slate-600 uppercase tracking-widest text-[8px] mb-1">Standard Payment Terms</h4>
                <p>
                  Please settle outstanding retainers within 15 days of invoice date issuance. Automated recurring charges occur standardly on the 1st business morning of each month. Late fees representing 2.5% accrue compounding per calendar week overdue.
                </p>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* MODAL 2: RENEGOTIATION FORM */}
      {isRenegotiateOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <form 
            onSubmit={handleSaveRenegotiation}
            className="w-full max-w-md bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col animate-in zoom-in-95 duration-200"
          >
            <div className="p-5 border-b border-slate-900 bg-slate-900/40 flex justify-between items-center text-slate-200">
              <h3 className="text-sm font-bold flex items-center gap-1.5">
                <Settings className={`w-4 h-4 ${getBrandTextColor()}`} /> Price Renegotiation Panel
              </h3>
              <button type="button" onClick={() => setIsRenegotiateOpen(false)} className="p-1 hover:bg-slate-800 text-slate-400 rounded-lg cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              
              <div className="grid grid-cols-2 gap-3.5">
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Invoice ID</label>
                  <input type="text" readOnly value={`#INV-${renegotiateForm.invoiceId}`} className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-500 font-bold focus:outline-none" />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Client Brand</label>
                  <input type="text" readOnly value={renegotiateForm.clientName} className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-500 font-bold focus:outline-none" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Baseline Rate</label>
                  <div className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-400 font-bold select-none">${renegotiateForm.oldPrice.toLocaleString()}</div>
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">New Revised Rate ($) *</label>
                  <input 
                    type="number" required
                    placeholder="Enter revised pricing"
                    value={renegotiateForm.newPrice}
                    onChange={(e) => setRenegotiateForm({...renegotiateForm, newPrice: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none font-bold"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-400 font-medium">Auditor Notes & Renegotiation Rationale</label>
                <textarea 
                  placeholder="e.g. Matched pricing under SEO discount promotion, or added Custom CMS retainer scope..."
                  rows="3"
                  value={renegotiateForm.note}
                  onChange={(e) => setRenegotiateForm({...renegotiateForm, note: e.target.value})}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none resize-none"
                />
              </div>

            </div>

            <div className="p-4 border-t border-slate-900 bg-slate-900/40 flex justify-end gap-2">
              <button 
                type="button" 
                onClick={() => setIsRenegotiateOpen(false)}
                className="px-4 py-2 bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className={`px-4 py-2 ${getBrandBg()} text-white rounded-xl text-xs font-bold cursor-pointer hover:scale-105 active:scale-95 transition-all shadow-md`}
              >
                Approve Price Revision
              </button>
            </div>
          </form>
        </div>
      )}

      {/* MODAL 3: CREATE CUSTOM INVOICE */}
      {isCreateInvoiceOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <form 
            onSubmit={handleCreateInvoice}
            className="w-full max-w-md bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col animate-in zoom-in-95 duration-200"
          >
            <div className="p-5 border-b border-slate-900 bg-slate-900/40 flex justify-between items-center text-slate-200">
              <h3 className="text-sm font-bold flex items-center gap-1.5">
                <Plus className={`w-4 h-4 ${getBrandTextColor()}`} /> Generate Custom Invoice
              </h3>
              <button type="button" onClick={() => setIsCreateInvoiceOpen(false)} className="p-1 hover:bg-slate-800 text-slate-400 rounded-lg cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              
              <div className="space-y-1">
                <label className="text-slate-400 font-medium">Select Corporate Partner *</label>
                <select 
                  value={createInvoiceForm.clientId}
                  onChange={(e) => setCreateInvoiceForm({...createInvoiceForm, clientId: e.target.value})}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none cursor-pointer"
                >
                  {clients.map(cli => (
                    <option key={cli.id} value={cli.id} className="bg-slate-950 text-slate-300">
                      {cli.companyName} ({cli.industry})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Base Retainer ($) *</label>
                  <input 
                    type="number" required
                    placeholder="e.g. 3500"
                    value={createInvoiceForm.amount}
                    onChange={(e) => setCreateInvoiceForm({...createInvoiceForm, amount: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none font-bold"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Due Date *</label>
                  <input 
                    type="date" required
                    value={createInvoiceForm.dueDate}
                    onChange={(e) => setCreateInvoiceForm({...createInvoiceForm, dueDate: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none font-bold"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-400 font-medium">Campaign Scope / Deliverables (comma separated) *</label>
                <input 
                  type="text" required
                  placeholder="e.g. Advanced Search Audit, Q4 Influencer Setup, High-PR Backlinks"
                  value={createInvoiceForm.deliverables}
                  onChange={(e) => setCreateInvoiceForm({...createInvoiceForm, deliverables: e.target.value})}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input 
                  type="checkbox"
                  id="createInvRecurring"
                  checked={createInvoiceForm.recurring}
                  onChange={(e) => setCreateInvoiceForm({...createInvoiceForm, recurring: e.target.checked})}
                  className="w-4 h-4 bg-slate-900 border-slate-800 text-indigo-500 rounded focus:ring-indigo-500/30 cursor-pointer"
                />
                <label htmlFor="createInvRecurring" className="text-slate-400 font-bold select-none cursor-pointer">
                  Activate auto-recurring monthly cycle retainer
                </label>
              </div>

            </div>

            <div className="p-4 border-t border-slate-900 bg-slate-900/40 flex justify-end gap-2">
              <button 
                type="button" 
                onClick={() => setIsCreateInvoiceOpen(false)}
                className="px-4 py-2 bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className={`px-4 py-2 ${getBrandBg()} text-white rounded-xl text-xs font-bold cursor-pointer hover:scale-105 active:scale-95 transition-all shadow-md`}
              >
                Compile & Dispatch Invoice
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
}
