import { isConfigured, auth, db } from './firebase';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut as fbSignOut, 
  updateProfile
} from 'firebase/auth';
import { 
  collection, 
  doc, 
  setDoc, 
  getDocs, 
  query, 
  where 
} from 'firebase/firestore';

// Default static invoices to load if a user is new and has no invoices saved yet
import { INITIAL_INVOICES } from './mockData';

// Simulated latency to mimic Firestore and Auth network requests (800ms)
const simulateDelay = () => new Promise(resolve => setTimeout(resolve, 800));

class FirebaseService {
  constructor() {
    this.authListeners = new Set();
    this.currentUser = null;
    
    // In local simulation mode, initialize session from localStorage
    if (!isConfigured) {
      // Seed default users if they do not exist
      const simUsers = JSON.parse(localStorage.getItem('omnimark_sim_users') || '{}');
      let updated = false;
      
      if (!simUsers['admin@aurascale.io']) {
        simUsers['admin@aurascale.io'] = {
          uid: 'sim-admin-uid',
          email: 'admin@aurascale.io',
          displayName: 'RAJIB (Admin)',
          role: 'admin',
          password: 'admin123'
        };
        updated = true;
      }
      if (!simUsers['team@aurascale.io']) {
        simUsers['team@aurascale.io'] = {
          uid: 'sim-team-uid',
          email: 'team@aurascale.io',
          displayName: 'Chloe Chen',
          role: 'team',
          password: 'team123'
        };
        updated = true;
      }
      if (!simUsers['client@aurascale.io']) {
        simUsers['client@aurascale.io'] = {
          uid: 'sim-client-uid',
          email: 'client@aurascale.io',
          displayName: 'AeroMedia Group',
          role: 'client',
          password: 'client123'
        };
        updated = true;
      }
      
      if (updated) {
        localStorage.setItem('omnimark_sim_users', JSON.stringify(simUsers));
      }

      const savedUser = localStorage.getItem('omnimark_auth_user');
      if (savedUser) {
        try {
          this.currentUser = JSON.parse(savedUser);
        } catch (e) {
          console.error('Failed to parse simulated session user', e);
        }
      }
    } else {
      // Connect real Firebase auth observer
      auth.onAuthStateChanged(async (fbUser) => {
        if (fbUser) {
          this.currentUser = {
            uid: fbUser.uid,
            email: fbUser.email,
            displayName: fbUser.displayName || fbUser.email.split('@')[0],
            role: fbUser.photoURL || 'admin' // We'll store role in photoURL for standard auth metadata sync
          };
        } else {
          this.currentUser = null;
        }
        this._notifyListeners();
      });
    }
  }

  // Register listener for auth state changes
  onAuthChange(callback) {
    this.authListeners.add(callback);
    // Execute immediately for initial state
    callback(this.currentUser);
    return () => {
      this.authListeners.delete(callback);
    };
  }

  _notifyListeners() {
    this.authListeners.forEach(cb => cb(this.currentUser));
  }

  // Get current active user
  getCurrentUser() {
    return this.currentUser;
  }

  // Register User
  async registerUser(name, email, password, role = 'admin') {
    if (isConfigured) {
      // Production Flow
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      // We leverage display name and photoURL for standard role & profile syncing in firebase auth
      await updateProfile(userCredential.user, {
        displayName: name,
        photoURL: role
      });
      
      // Save metadata record in Firestore for references
      await setDoc(doc(db, 'users', userCredential.user.uid), {
        name,
        email,
        role,
        createdAt: new Date().toISOString()
      });

      this.currentUser = {
        uid: userCredential.user.uid,
        email: userCredential.user.email,
        displayName: name,
        role: role
      };
      
      // Seed initial invoices in Firestore for this new user so they have data
      await this._seedInitialInvoices(userCredential.user.uid);
      
      return this.currentUser;
    } else {
      // Local Storage Simulation Flow
      await simulateDelay();
      
      // Load existing simulation registry
      const simUsers = JSON.parse(localStorage.getItem('omnimark_sim_users') || '{}');
      if (simUsers[email]) {
        throw new Error('An account with this email address already exists.');
      }

      const uid = `sim-uid-${Date.now()}`;
      const newUser = { uid, email, displayName: name, role, password };
      
      simUsers[email] = newUser;
      localStorage.setItem('omnimark_sim_users', JSON.stringify(simUsers));

      // Active Session User (exclude password)
      const sessionUser = { uid, email, displayName: name, role };
      this.currentUser = sessionUser;
      localStorage.setItem('omnimark_auth_user', JSON.stringify(sessionUser));
      
      // Seed initial invoices in simulated localStorage
      this._seedSimulatedInvoices(uid);

      this._notifyListeners();
      return this.currentUser;
    }
  }

  // Create client login credential safely without changing current active user session
  async createClientLogin(name, email, password) {
    if (isConfigured) {
      // Production Firestore Persistence: Save credential records securely in a collection
      // so we can on-the-fly create the actual Auth account when the client logs in first time.
      const docId = email.replace(/[^a-zA-Z0-9]/g, '_');
      await setDoc(doc(db, 'client_logins', docId), {
        name,
        email,
        password, // stored for onboarding reveal and on-the-fly Auth creation
        role: 'client',
        createdAt: new Date().toISOString()
      });
      
      // Also register a basic user profile record in Firestore
      await setDoc(doc(db, 'users', docId), {
        name,
        email,
        role: 'client',
        createdAt: new Date().toISOString()
      });
    } else {
      // Simulated Local Storage Registry
      await simulateDelay();
      const simUsers = JSON.parse(localStorage.getItem('omnimark_sim_users') || '{}');
      const uid = `sim-uid-${Date.now()}`;
      
      // Register in sim database
      simUsers[email] = {
        uid,
        email,
        displayName: name,
        role: 'client',
        password
      };
      localStorage.setItem('omnimark_sim_users', JSON.stringify(simUsers));
    }
  }

  // Sign In
  async signIn(email, password) {
    if (isConfigured) {
      // Production Flow
      try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        this.currentUser = {
          uid: userCredential.user.uid,
          email: userCredential.user.email,
          displayName: userCredential.user.displayName || email.split('@')[0],
          role: userCredential.user.photoURL || 'admin'
        };
        return this.currentUser;
      } catch (error) {
        // If sign in fails, check if there is an onboarded client in our custom credentials vault
        if (error.code === 'auth/user-not-found' || error.code === 'auth/invalid-credential') {
          try {
            const docId = email.replace(/[^a-zA-Z0-9]/g, '_');
            // Query Firestore client logins
            const docSnap = await getDocs(query(collection(db, 'client_logins'), where('email', '==', email)));
            let match = null;
            docSnap.forEach(d => {
              if (d.data().password === password) {
                match = d.data();
              }
            });
            
            if (match) {
              // Create the user on the fly!
              const userCredential = await createUserWithEmailAndPassword(auth, email, password);
              await updateProfile(userCredential.user, {
                displayName: match.name,
                photoURL: 'client'
              });
              this.currentUser = {
                uid: userCredential.user.uid,
                email: userCredential.user.email,
                displayName: match.name,
                role: 'client'
              };
              return this.currentUser;
            }
          } catch (fsError) {
            console.error('Failed on-the-fly client creation check:', fsError);
          }
        }
        throw error;
      }
    } else {
      // Local Storage Simulation Flow
      await simulateDelay();

      const simUsers = JSON.parse(localStorage.getItem('omnimark_sim_users') || '{}');
      const user = simUsers[email];
      
      if (!user || user.password !== password) {
        throw new Error('Invalid email credentials or incorrect password.');
      }

      const sessionUser = {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        role: user.role
      };

      this.currentUser = sessionUser;
      localStorage.setItem('omnimark_auth_user', JSON.stringify(sessionUser));
      this._notifyListeners();
      return this.currentUser;
    }
  }

  // Sign Out
  async signOut() {
    if (isConfigured) {
      await fbSignOut(auth);
      this.currentUser = null;
    } else {
      await simulateDelay();
      this.currentUser = null;
      localStorage.removeItem('omnimark_auth_user');
      this._notifyListeners();
    }
  }

  // Load Invoices for active User
  async getUserInvoices() {
    if (!this.currentUser) return [];

    if (isConfigured) {
      // Production Firestore Retrieval
      try {
        const q = query(collection(db, 'invoices'), where('userId', '==', this.currentUser.uid));
        const querySnapshot = await getDocs(q);
        const fbInvoices = [];
        querySnapshot.forEach((docSnap) => {
          fbInvoices.push({ id: docSnap.id, ...docSnap.data() });
        });
        
        // If user is logged in but Firestore records are 0 (e.g. newly registered), seed & return
        if (fbInvoices.length === 0) {
          return await this._seedInitialInvoices(this.currentUser.uid);
        }

        // Sort by id chronologically
        return fbInvoices.sort((a, b) => b.id.localeCompare(a.id));
      } catch (error) {
        console.error('Firestore get invoices error:', error);
        return [];
      }
    } else {
      // Local Storage Simulation Retrieval
      await simulateDelay();
      const storageKey = `omnimark_sim_invoices_${this.currentUser.uid}`;
      const saved = localStorage.getItem(storageKey);
      
      if (!saved) {
        // Return seeded initial default invoices list
        return this._seedSimulatedInvoices(this.currentUser.uid);
      }
      return JSON.parse(saved);
    }
  }

  // Save Invoices list securely (used for updates, new invoices, or renegotiations)
  async saveUserInvoices(invoicesList) {
    if (!this.currentUser) return;

    if (isConfigured) {
      // Production Firestore persistence
      try {
        const promises = invoicesList.map(async (invoice) => {
          // Add userId metadata
          const docData = {
            ...invoice,
            userId: this.currentUser.uid,
            updatedAt: new Date().toISOString()
          };
          // Use invoice ID as doc path key
          await setDoc(doc(db, 'invoices', invoice.id), docData);
        });
        await Promise.all(promises);
      } catch (error) {
        console.error('Firestore save invoices error:', error);
        throw error;
      }
    } else {
      // Local Storage simulation persistence
      await simulateDelay();
      const storageKey = `omnimark_sim_invoices_${this.currentUser.uid}`;
      localStorage.setItem(storageKey, JSON.stringify(invoicesList));
    }
  }

  // Internal: Seed Firestore initial invoices for a brand-new user session
  async _seedInitialInvoices(userId) {
    try {
      const seeded = INITIAL_INVOICES.map(inv => ({
        ...inv,
        userId: userId,
        seeded: true
      }));
      
      const promises = seeded.map(async (invoice) => {
        await setDoc(doc(db, 'invoices', invoice.id), invoice);
      });
      await Promise.all(promises);
      return seeded;
    } catch (e) {
      console.error('Failed seeding default invoices in Firestore', e);
      return INITIAL_INVOICES;
    }
  }

  // Internal: Seed simulated localStorage invoices
  _seedSimulatedInvoices(userId) {
    const storageKey = `omnimark_sim_invoices_${userId}`;
    localStorage.setItem(storageKey, JSON.stringify(INITIAL_INVOICES));
    return INITIAL_INVOICES;
  }
}

const firebaseService = new FirebaseService();
export default firebaseService;
