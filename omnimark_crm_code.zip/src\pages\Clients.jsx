import React, { useState } from 'react';
import { 
  Plus, Search, SlidersHorizontal, Globe, Mail, Phone, 
  Trash2, Edit, X, FolderOpen, FileText, CheckCircle, Clock,
  Key, RefreshCw, Eye, EyeOff
} from 'lucide-react';
import firebaseService from '../firebaseService';

export default function Clients({ 
  clients, 
  setClients, 
  logActivity, 
  brandColor = 'indigo' 
}) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [sortBy, setSortBy] = useState('name'); // name, billing, status
  const [selectedClient, setSelectedClient] = useState(null);
  const [showProfilePassword, setShowProfilePassword] = useState(false);
  
  // Modals / Drawer toggles
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);

  // Forms state
  const [newClient, setNewClient] = useState({
    companyName: '', contactPerson: '', email: '', phone: '',
    website: '', industry: 'Aviation & Tech', status: 'Active',
    monthlyBilling: '', activeServices: [], projectStatus: 'On Track', notes: '',
    portalEmail: '', portalPassword: ''
  });

  const generateStrongPassword = () => {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
    let pwd = "";
    for (let i = 0; i < 12; i++) {
      pwd += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return pwd;
  };

  const [editClientData, setEditClientData] = useState(null);

  // Available industry listings
  const industries = ['Aviation & Tech', 'Healthcare & Pharma', 'Retail & E-commerce', 'Renewables', 'Education & EdTech', 'Real Estate', 'Logistics'];

  // Global available services for selectors
  const ALL_SERVICES_LIST = ['SEO Optimization', 'Social Media Marketing', 'Google Ads Management', 'Website Development', 'Branding & Design', 'Video Production & Editing', 'Online Reputation Management'];

  // Dynamic filter application
  const filteredClients = clients
    .filter(c => {
      const matchSearch = c.companyName.toLowerCase().includes(search.toLowerCase()) || 
                          c.contactPerson.toLowerCase().includes(search.toLowerCase()) || 
                          c.industry.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === 'All' ? true : c.status === statusFilter;
      return matchSearch && matchStatus;
    })
    .sort((a, b) => {
      if (sortBy === 'billing') return b.monthlyBilling - a.monthlyBilling;
      if (sortBy === 'status') return a.status.localeCompare(b.status);
      return a.companyName.localeCompare(b.companyName);
    });

  // Action: Add Client
  const handleAddClient = async (e) => {
    e.preventDefault();
    if (!newClient.companyName || !newClient.contactPerson || !newClient.email) {
      alert('Please fill out critical details (Company Name, Contact Person, Email)');
      return;
    }

    const portalEmailVal = newClient.portalEmail || newClient.email;
    const portalPasswordVal = newClient.portalPassword || 'client123';

    try {
      await firebaseService.createClientLogin(
        newClient.companyName,
        portalEmailVal,
        portalPasswordVal
      );
    } catch (err) {
      console.error('Failed to create client credential:', err);
    }

    const clientToAdd = {
      ...newClient,
      portalEmail: portalEmailVal,
      portalPassword: portalPasswordVal,
      id: `cli-${Date.now()}`,
      monthlyBilling: parseFloat(newClient.monthlyBilling) || 0,
      documents: ['Master_Engagement_Agreement.pdf'],
      activeServices: newClient.activeServices.length > 0 ? newClient.activeServices : ['SEO Optimization']
    };

    setClients(prev => [clientToAdd, ...prev]);
    logActivity('Added Partner Account', `Registered brand ${clientToAdd.companyName} with active portal onboarding.`);
    
    // Reset state
    setNewClient({
      companyName: '', contactPerson: '', email: '', phone: '',
      website: '', industry: 'Aviation & Tech', status: 'Active',
      monthlyBilling: '', activeServices: [], projectStatus: 'On Track', notes: '',
      portalEmail: '', portalPassword: ''
    });
    setIsAddOpen(false);
  };

  // Action: Edit Client Trigger
  const openEditModal = (client) => {
    setEditClientData({ ...client });
    setIsEditOpen(true);
  };

  // Action: Save Edited Client
  const handleEditClientSubmit = async (e) => {
    e.preventDefault();
    if (!editClientData.companyName || !editClientData.contactPerson || !editClientData.email) return;

    const portalEmailVal = editClientData.portalEmail || editClientData.email;
    const portalPasswordVal = editClientData.portalPassword || 'client123';

    try {
      await firebaseService.createClientLogin(
        editClientData.companyName,
        portalEmailVal,
        portalPasswordVal
      );
    } catch (err) {
      console.error('Failed to update client credential:', err);
    }

    setClients(prev => prev.map(c => c.id === editClientData.id ? {
      ...editClientData,
      portalEmail: portalEmailVal,
      portalPassword: portalPasswordVal,
      monthlyBilling: parseFloat(editClientData.monthlyBilling) || 0
    } : c));

    logActivity('Updated Partner Details', `Modified database profiles and access credentials for ${editClientData.companyName}.`);
    
    // Update selected profile view
    if (selectedClient && selectedClient.id === editClientData.id) {
      setSelectedClient({ 
        ...editClientData,
        portalEmail: portalEmailVal,
        portalPassword: portalPasswordVal
      });
    }
    
    setIsEditOpen(false);
  };

  // Action: Delete Client
  const handleDeleteClient = (id, name) => {
    if (confirm(`Are you absolutely sure you want to terminate account ${name}? This action is irreversible.`)) {
      setClients(prev => prev.filter(c => c.id !== id));
      logActivity('Partner Account Terminated', `Removed brand ${name} and related billing records.`);
      setSelectedClient(null);
    }
  };

  // Action: Add mock document file
  const handleUploadMockDoc = (clientId) => {
    const docName = prompt('Enter the file name to upload (e.g. Campaign_Brief_Q3.pdf):');
    if (!docName) return;

    setClients(prev => prev.map(c => {
      if (c.id === clientId) {
        const docs = c.documents ? [...c.documents, docName] : [docName];
        logActivity('Document Asset Uploaded', `Uploaded ${docName} to ${c.companyName} portal directory.`);
        const updated = { ...c, documents: docs };
        if (selectedClient && selectedClient.id === clientId) {
          setSelectedClient(updated);
        }
        return updated;
      }
      return c;
    }));
  };

  // Color mappings
  const getBrandTextColor = () => {
    switch (brandColor) {
      case 'emerald': return 'text-emerald-400';
      case 'violet': return 'text-violet-400';
      case 'amber': return 'text-amber-400';
      default: return 'text-indigo-400';
    }
  };

  const getBrandBg = () => {
    switch (brandColor) {
      case 'emerald': return 'bg-emerald-500';
      case 'violet': return 'bg-violet-500';
      case 'amber': return 'bg-amber-500';
      default: return 'bg-indigo-500';
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Active': return 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400';
      case 'Paused': return 'bg-amber-500/10 border-amber-500/30 text-amber-400';
      case 'Pending': return 'bg-blue-500/10 border-blue-500/30 text-blue-400';
      default: return 'bg-slate-800 border-slate-700 text-slate-400';
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top action row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-slate-100">Partners & Clients Directory</h2>
          <p className="text-xs text-slate-400 mt-1">Manage active enterprise profiles, invoices access credentials, and pipeline status logs.</p>
        </div>
        <button 
          onClick={() => setIsAddOpen(true)}
          className={`flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white rounded-xl shadow-md cursor-pointer transition-all hover:scale-105 active:scale-95 ${getBrandBg()}`}
        >
          <Plus className="w-4 h-4" /> Add Partner Account
        </button>
      </div>

      {/* Filter and control panel */}
      <div className="p-4 bg-slate-900 border border-slate-800/80 rounded-2xl flex flex-col md:flex-row justify-between gap-4">
        
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
          <input 
            type="text" 
            placeholder="Search company, manager contact, or industry..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-300 placeholder-slate-500 focus:outline-none focus:border-slate-700 focus:ring-1 focus:ring-slate-700"
          />
        </div>

        {/* Status filtering row */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="text-slate-500 font-semibold mr-1.5 flex items-center gap-1.5">
            <SlidersHorizontal className="w-3.5 h-3.5" /> Filter Status:
          </span>
          {['All', 'Active', 'Pending', 'Paused', 'Completed'].map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`px-3 py-1.5 rounded-lg cursor-pointer transition-all font-bold ${
                statusFilter === status 
                  ? `${getBrandBg()} text-white shadow-md` 
                  : 'bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-400'
              }`}
            >
              {status}
            </button>
          ))}
        </div>

        {/* Sorting selection */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-500 font-semibold shrink-0">Sort By:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="bg-slate-950 border border-slate-800 text-slate-300 py-1.5 px-3 rounded-lg text-xs font-semibold focus:outline-none cursor-pointer"
          >
            <option value="name">Company Name</option>
            <option value="billing">Highest Billing</option>
            <option value="status">Partner Status</option>
          </select>
        </div>

      </div>

      {/* Main Partners Listing */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredClients.map((client) => (
          <div 
            key={client.id}
            className="p-5 rounded-2xl glassmorphism-card border border-slate-800 flex flex-col justify-between"
          >
            <div>
              {/* Header: Logo avatar and status */}
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center font-bold text-sm ${getBrandTextColor()}`}>
                    {client.companyName.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-200 leading-tight">{client.companyName}</h3>
                    <span className="text-[9px] text-slate-500 font-semibold">{client.industry}</span>
                  </div>
                </div>

                <span className={`text-[8px] font-extrabold uppercase border px-2 py-0.5 rounded-full shadow-inner ${getStatusBadge(client.status)}`}>
                  {client.status}
                </span>
              </div>

              {/* Contact row details */}
              <div className="space-y-2 mt-5 text-[10px] text-slate-400 border-t border-slate-900/60 pt-4">
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-slate-600" />
                  <span className="truncate">{client.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Globe className="w-3.5 h-3.5 text-slate-600" />
                  <a href={client.website} target="_blank" rel="noreferrer" className="hover:underline hover:text-slate-300 truncate">
                    {client.website.replace('https://', '')}
                  </a>
                </div>
              </div>

              {/* Service list pills */}
              <div className="mt-4 flex flex-wrap gap-1">
                {client.activeServices.slice(0, 2).map((srv, idx) => (
                  <span key={idx} className="text-[8px] font-bold bg-slate-900 text-slate-300 px-2 py-0.5 rounded-md border border-slate-800/80">
                    {srv}
                  </span>
                ))}
                {client.activeServices.length > 2 && (
                  <span className="text-[8px] font-bold bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded-md">
                    +{client.activeServices.length - 2} more
                  </span>
                )}
              </div>
            </div>

            {/* Billing footer and open detail triggers */}
            <div className="mt-5 pt-4 border-t border-slate-900/60 flex items-center justify-between">
              <div>
                <span className="text-[8px] uppercase tracking-wider font-bold text-slate-500">Monthly Contract</span>
                <div className="text-sm font-bold text-slate-100 mt-0.5">
                  ${client.monthlyBilling.toLocaleString()}<span className="text-[10px] text-slate-500 font-medium">/mo</span>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => openEditModal(client)}
                  className="p-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 rounded-lg text-slate-400 hover:text-slate-200 cursor-pointer transition-all"
                  title="Edit Account Details"
                >
                  <Edit className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setSelectedClient(client)}
                  className={`text-[10px] font-bold bg-slate-950 hover:bg-slate-900 border border-slate-800/80 hover:border-slate-700 text-slate-300 px-3 py-2 rounded-lg cursor-pointer transition-all`}
                >
                  Inspect Profile
                </button>
              </div>
            </div>

          </div>
        ))}

        {filteredClients.length === 0 && (
          <div className="col-span-full py-12 text-center bg-slate-950/40 border border-slate-900 rounded-2xl">
            <FolderOpen className="w-8 h-8 text-slate-600 mx-auto mb-2.5" />
            <h4 className="text-xs font-bold text-slate-400">No partner accounts match this scan query</h4>
            <p className="text-[10px] text-slate-600 mt-1">Try modifying search tags or registering a new company.</p>
          </div>
        )}
      </div>

      {/* MODAL 1: INSPECT PROFILE DETAILS */}
      {selectedClient && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-2xl bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200">
            
            {/* Header */}
            <div className="p-6 border-b border-slate-900 flex justify-between items-start bg-slate-900/40">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center font-bold text-lg ${getBrandTextColor()}`}>
                  {selectedClient.companyName.charAt(0)}
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-100">{selectedClient.companyName}</h3>
                  <p className="text-xs text-slate-500 mt-0.5">Manager Contact: <span className="text-slate-300 font-semibold">{selectedClient.contactPerson}</span></p>
                </div>
              </div>
              <div className="flex gap-2">
                <span className={`text-[9px] font-extrabold uppercase border px-3 py-1 rounded-full shadow-inner ${getStatusBadge(selectedClient.status)}`}>
                  {selectedClient.status}
                </span>
                <button onClick={() => setSelectedClient(null)} className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded-lg cursor-pointer">
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Content Body */}
            <div className="flex-1 p-6 overflow-y-auto space-y-6">
              
              {/* Profile grid summary info */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3.5 bg-slate-900/40 border border-slate-900 rounded-xl text-xs space-y-1.5">
                  <div className="text-[9px] uppercase tracking-wider font-bold text-slate-500">Contact Details</div>
                  <div className="text-slate-300 truncate"><span className="text-slate-500">Email:</span> {selectedClient.email}</div>
                  <div className="text-slate-300"><span className="text-slate-500">Phone:</span> {selectedClient.phone || 'Not Registered'}</div>
                  <div className="text-slate-300 truncate"><span className="text-slate-500">Website:</span> <a href={selectedClient.website} target="_blank" rel="noreferrer" className="text-indigo-400 hover:underline">{selectedClient.website}</a></div>
                </div>

                <div className="p-3.5 bg-slate-900/40 border border-slate-900 rounded-xl text-xs space-y-1.5">
                  <div className="text-[9px] uppercase tracking-wider font-bold text-slate-500">Operations Summary</div>
                  <div className="text-slate-300"><span className="text-slate-500">Industry:</span> {selectedClient.industry}</div>
                  <div className="text-slate-300"><span className="text-slate-500">Monthly Billing:</span> ${selectedClient.monthlyBilling.toLocaleString()}/mo</div>
                  <div className="text-slate-300 flex items-center gap-1.5"><span className="text-slate-500">Workflow Velocity:</span> 
                    <span className="bg-emerald-500/15 text-emerald-400 px-1.5 py-0.5 rounded font-extrabold text-[9px]">{selectedClient.projectStatus}</span>
                  </div>
                </div>
              </div>

              {/* Active Subscribed Services list */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 mb-2">Active Services Subscriptions</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedClient.activeServices.map((srv, index) => (
                    <span key={index} className="text-xs font-semibold bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 py-1.5 px-3 rounded-xl transition-all">
                      ⚡ {srv}
                    </span>
                  ))}
                </div>
              </div>

              {/* Internal Manager Notes */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 mb-2">Internal Agency Profile Notes</h4>
                <div className="p-4 bg-slate-900/50 border border-slate-900 text-xs text-slate-300 rounded-xl leading-relaxed whitespace-pre-line italic">
                  {selectedClient.notes || 'No custom notes recorded for this partner account.'}
                </div>
              </div>

              {/* Portal Authentication & Keys Vault */}
              <div className="p-4 bg-slate-900/40 border border-slate-900 rounded-xl space-y-3">
                <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-400 block flex items-center gap-1.5 border-b border-slate-950 pb-2">
                  <Key className="w-3.5 h-3.5 text-indigo-400" /> Portal Authentication & Keys Vault
                </span>
                
                <div className="grid grid-cols-2 gap-4 text-[11px]">
                  <div className="space-y-1">
                    <span className="text-slate-500 font-semibold block">Onboarding Login Email</span>
                    <span className="text-slate-200 font-mono select-all bg-slate-950 px-2.5 py-1.5 rounded-lg border border-slate-850 block truncate" title="Click to select email">
                      {selectedClient.portalEmail || selectedClient.email || 'client@aurascale.io'}
                    </span>
                  </div>
                  <div className="space-y-1">
                    <span className="text-slate-500 font-semibold block">Portal Access Password</span>
                    <div className="relative flex items-center bg-slate-950 rounded-lg border border-slate-850 px-2.5 py-1.5">
                      <span className="text-slate-200 font-mono select-all block truncate flex-1">
                        {showProfilePassword 
                          ? (selectedClient.portalPassword || 'client123') 
                          : '••••••••••••'}
                      </span>
                      <button 
                        type="button"
                        onClick={() => setShowProfilePassword(!showProfilePassword)}
                        className="p-0.5 hover:text-slate-200 text-slate-500 transition-colors cursor-pointer"
                        title={showProfilePassword ? "Mask Password" : "Reveal Password"}
                      >
                        {showProfilePassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Documents and Files Vault */}
              <div>
                <div className="flex justify-between items-center mb-2.5">
                  <h4 className="text-xs font-bold text-slate-400">Documents Vault</h4>
                  <button 
                    onClick={() => handleUploadMockDoc(selectedClient.id)}
                    className="text-[9px] uppercase font-bold text-indigo-400 hover:underline cursor-pointer"
                  >
                    + Upload Document
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {selectedClient.documents && selectedClient.documents.map((doc, index) => (
                    <div 
                      key={index}
                      className="p-3 bg-slate-900/25 border border-slate-900 hover:border-slate-800 rounded-xl flex items-center gap-2.5 text-xs text-slate-300 transition-all select-none cursor-pointer"
                      onClick={() => alert(`Opening document asset file: "${doc}"`)}
                    >
                      <FileText className="w-4 h-4 text-indigo-400 shrink-0" />
                      <span className="truncate">{doc}</span>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* Footer triggers */}
            <div className="p-4 border-t border-slate-900 flex justify-between bg-slate-900/40">
              <button
                onClick={() => handleDeleteClient(selectedClient.id, selectedClient.companyName)}
                className="flex items-center gap-1 text-xs font-bold text-red-500 hover:text-red-400 py-2 px-3 rounded-lg hover:bg-red-500/5 cursor-pointer transition-all"
              >
                <Trash2 className="w-4 h-4" /> Terminate Account Contract
              </button>
              <div className="flex gap-2">
                <button
                  onClick={() => openEditModal(selectedClient)}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-slate-300 rounded-xl text-xs font-bold cursor-pointer transition-all"
                >
                  Edit Profile Fields
                </button>
                <button
                  onClick={() => setSelectedClient(null)}
                  className={`px-4 py-2 ${getBrandBg()} text-white rounded-xl text-xs font-bold cursor-pointer hover:scale-105 active:scale-95 transition-all shadow-md`}
                >
                  Close Profile
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* MODAL 2: ADD PARTNER FORM */}
      {isAddOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <form 
            onSubmit={handleAddClient}
            className="w-full max-w-lg bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
          >
            <div className="p-5 border-b border-slate-900 bg-slate-900/40 flex justify-between items-center">
              <h3 className="text-sm font-bold text-slate-100">Register New Partner Account</h3>
              <button type="button" onClick={() => setIsAddOpen(false)} className="p-1 hover:bg-slate-800 text-slate-400 rounded-lg cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
              
              <div className="grid grid-cols-2 gap-3.5">
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Company Name *</label>
                  <input 
                    type="text" required
                    placeholder="e.g. AeroMedia Group"
                    value={newClient.companyName}
                    onChange={(e) => setNewClient({...newClient, companyName: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Industry</label>
                  <select 
                    value={newClient.industry}
                    onChange={(e) => setNewClient({...newClient, industry: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none cursor-pointer"
                  >
                    {industries.map(ind => <option key={ind} value={ind}>{ind}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Contact Person *</label>
                  <input 
                    type="text" required
                    placeholder="Sarah Jenkins"
                    value={newClient.contactPerson}
                    onChange={(e) => setNewClient({...newClient, contactPerson: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Website</label>
                  <input 
                    type="text" 
                    placeholder="https://aeromedia.com"
                    value={newClient.website}
                    onChange={(e) => setNewClient({...newClient, website: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Email *</label>
                  <input 
                    type="email" required
                    placeholder="manager@company.com"
                    value={newClient.email}
                    onChange={(e) => setNewClient({...newClient, email: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Phone</label>
                  <input 
                    type="text" 
                    placeholder="+1 (555) 234-5678"
                    value={newClient.phone}
                    onChange={(e) => setNewClient({...newClient, phone: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Monthly Billing Cost ($)</label>
                  <input 
                    type="number" 
                    placeholder="4500"
                    value={newClient.monthlyBilling}
                    onChange={(e) => setNewClient({...newClient, monthlyBilling: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Contract Status</label>
                  <select 
                    value={newClient.status}
                    onChange={(e) => setNewClient({...newClient, status: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none cursor-pointer"
                  >
                    <option value="Active">Active</option>
                    <option value="Pending">Pending</option>
                    <option value="Paused">Paused</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>
              </div>

              {/* Service list multiselect */}
              <div className="space-y-1.5">
                <label className="text-slate-400 font-medium">Core Marketing Subscriptions</label>
                <div className="grid grid-cols-2 gap-2 p-3 bg-slate-900/60 border border-slate-900 rounded-lg max-h-32 overflow-y-auto">
                  {ALL_SERVICES_LIST.map((srv) => {
                    const isChecked = newClient.activeServices.includes(srv);
                    return (
                      <label key={srv} className="flex items-center gap-2 text-[10px] text-slate-300 font-medium cursor-pointer">
                        <input 
                          type="checkbox" 
                          checked={isChecked}
                          onChange={() => {
                            if (isChecked) {
                              setNewClient({ ...newClient, activeServices: newClient.activeServices.filter(s => s !== srv) });
                            } else {
                              setNewClient({ ...newClient, activeServices: [...newClient.activeServices, srv] });
                            }
                          }}
                          className="rounded text-indigo-600 focus:ring-transparent border-slate-800 bg-slate-950"
                        />
                        <span>{srv}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Portal Credentials Onboarding */}
              <div className="border-t border-slate-900/60 pt-3.5 space-y-3">
                <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-400 block flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5 text-indigo-400" /> Client Portal Credentials Onboarding
                </span>
                <div className="grid grid-cols-2 gap-3.5">
                  <div className="space-y-1">
                    <label className="text-slate-400 font-medium">Onboarding Login Email</label>
                    <input 
                      type="email"
                      placeholder="client@aurascale.io"
                      value={newClient.portalEmail || newClient.email}
                      onChange={(e) => setNewClient({...newClient, portalEmail: e.target.value})}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-slate-400 font-medium flex justify-between items-center">
                      <span>Portal Access Password</span>
                      <button
                        type="button"
                        onClick={() => {
                          const generated = generateStrongPassword();
                          setNewClient({...newClient, portalPassword: generated});
                        }}
                        className="text-[9px] text-indigo-400 hover:underline flex items-center gap-1 cursor-pointer font-bold"
                      >
                        <RefreshCw className="w-2.5 h-2.5" /> Auto-Generate
                      </button>
                    </label>
                    <input 
                      type="text"
                      placeholder="Enter or generate password"
                      value={newClient.portalPassword}
                      onChange={(e) => setNewClient({...newClient, portalPassword: e.target.value})}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-400 font-medium">Internal Setup Notes</label>
                <textarea 
                  placeholder="Record onboarding notes or custom targets here..."
                  rows="3"
                  value={newClient.notes}
                  onChange={(e) => setNewClient({...newClient, notes: e.target.value})}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none resize-none"
                />
              </div>

            </div>

            <div className="p-4 border-t border-slate-900 bg-slate-900/40 flex justify-end gap-2">
              <button 
                type="button" 
                onClick={() => setIsAddOpen(false)}
                className="px-4 py-2 bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className={`px-4 py-2 ${getBrandBg()} text-white rounded-xl text-xs font-bold cursor-pointer hover:scale-105 active:scale-95 transition-all shadow-md`}
              >
                Register Partner
              </button>
            </div>
          </form>
        </div>
      )}

      {/* MODAL 3: EDIT PARTNER FORM */}
      {isEditOpen && editClientData && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <form 
            onSubmit={handleEditClientSubmit}
            className="w-full max-w-lg bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
          >
            <div className="p-5 border-b border-slate-900 bg-slate-900/40 flex justify-between items-center">
              <h3 className="text-sm font-bold text-slate-100">Edit Partner Specifications</h3>
              <button type="button" onClick={() => setIsEditOpen(false)} className="p-1 hover:bg-slate-800 text-slate-400 rounded-lg cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
              
              <div className="grid grid-cols-2 gap-3.5">
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Company Name *</label>
                  <input 
                    type="text" required
                    value={editClientData.companyName}
                    onChange={(e) => setEditClientData({...editClientData, companyName: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Industry</label>
                  <select 
                    value={editClientData.industry}
                    onChange={(e) => setEditClientData({...editClientData, industry: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none cursor-pointer"
                  >
                    {industries.map(ind => <option key={ind} value={ind}>{ind}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Contact Person *</label>
                  <input 
                    type="text" required
                    value={editClientData.contactPerson}
                    onChange={(e) => setEditClientData({...editClientData, contactPerson: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Website</label>
                  <input 
                    type="text" 
                    value={editClientData.website}
                    onChange={(e) => setEditClientData({...editClientData, website: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Email *</label>
                  <input 
                    type="email" required
                    value={editClientData.email}
                    onChange={(e) => setEditClientData({...editClientData, email: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Phone</label>
                  <input 
                    type="text" 
                    value={editClientData.phone}
                    onChange={(e) => setEditClientData({...editClientData, phone: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3.5">
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Monthly Billing Cost ($)</label>
                  <input 
                    type="number" 
                    value={editClientData.monthlyBilling}
                    onChange={(e) => setEditClientData({...editClientData, monthlyBilling: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-400 font-medium">Contract Status</label>
                  <select 
                    value={editClientData.status}
                    onChange={(e) => setEditClientData({...editClientData, status: e.target.value})}
                    className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none cursor-pointer"
                  >
                    <option value="Active">Active</option>
                    <option value="Pending">Pending</option>
                    <option value="Paused">Paused</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>
              </div>

              {/* Service list multiselect */}
              <div className="space-y-1.5">
                <label className="text-slate-400 font-medium">Core Marketing Subscriptions</label>
                <div className="grid grid-cols-2 gap-2 p-3 bg-slate-900/60 border border-slate-900 rounded-lg max-h-32 overflow-y-auto">
                  {ALL_SERVICES_LIST.map((srv) => {
                    const isChecked = editClientData.activeServices.includes(srv);
                    return (
                      <label key={srv} className="flex items-center gap-2 text-[10px] text-slate-300 font-medium cursor-pointer">
                        <input 
                          type="checkbox" 
                          checked={isChecked}
                          onChange={() => {
                            if (isChecked) {
                              setEditClientData({ ...editClientData, activeServices: editClientData.activeServices.filter(s => s !== srv) });
                            } else {
                              setEditClientData({ ...editClientData, activeServices: [...editClientData.activeServices, srv] });
                            }
                          }}
                          className="rounded text-indigo-600 focus:ring-transparent border-slate-800 bg-slate-950"
                        />
                        <span>{srv}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Portal Credentials Edit */}
              <div className="border-t border-slate-900/60 pt-3.5 space-y-3">
                <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-400 block flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5 text-indigo-400" /> Edit Client Portal Credentials
                </span>
                <div className="grid grid-cols-2 gap-3.5">
                  <div className="space-y-1">
                    <label className="text-slate-400 font-medium">Portal Login Email</label>
                    <input 
                      type="email"
                      value={editClientData.portalEmail || editClientData.email}
                      onChange={(e) => setEditClientData({...editClientData, portalEmail: e.target.value})}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-slate-400 font-medium flex justify-between items-center">
                      <span>Portal Password</span>
                      <button
                        type="button"
                        onClick={() => {
                          const generated = generateStrongPassword();
                          setEditClientData({...editClientData, portalPassword: generated});
                        }}
                        className="text-[9px] text-indigo-400 hover:underline flex items-center gap-1 cursor-pointer font-bold"
                      >
                        <RefreshCw className="w-2.5 h-2.5" /> Regenerate
                      </button>
                    </label>
                    <input 
                      type="text"
                      value={editClientData.portalPassword || 'client123'}
                      onChange={(e) => setEditClientData({...editClientData, portalPassword: e.target.value})}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-400 font-medium">Internal Profile Notes</label>
                <textarea 
                  rows="3"
                  value={editClientData.notes}
                  onChange={(e) => setEditClientData({...editClientData, notes: e.target.value})}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none resize-none"
                />
              </div>

            </div>

            <div className="p-4 border-t border-slate-900 bg-slate-900/40 flex justify-end gap-2">
              <button 
                type="button" 
                onClick={() => setIsEditOpen(false)}
                className="px-4 py-2 bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className={`px-4 py-2 ${getBrandBg()} text-white rounded-xl text-xs font-bold cursor-pointer hover:scale-105 active:scale-95 transition-all shadow-md`}
              >
                Save Details
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
}
